#pragma once


namespace SupDef {

    enum class MessageType {
        Init,
        Info,
        Warning,
        Error,
        Success
    };

}
