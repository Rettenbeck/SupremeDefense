#pragma once


namespace SupDef {

    enum class ActionType {
        None,
        Move,
        Attack,
        Build,
    };

}
