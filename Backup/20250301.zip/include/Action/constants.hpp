#include <Util/basic.hpp>

#pragma once


namespace SupDef {
    
    const std::string SA_TYPE                               = "type"                                ;
    const std::string SA_DATA                               = "data"                                ;

}