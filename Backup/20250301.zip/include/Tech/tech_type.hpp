#pragma once


namespace SupDef {

    enum class TechType {
        None,
        TechOne,
        TechTwo,
    };

}
