#pragma once

#include <Tech/tech_manager.hpp>
