#pragma once


namespace SupDef {
    
    enum class DependencyType {
        Independent,
        RequiresSource,
        GameManaged
    };
    
}
